package KAT;
//
// MasterThief.java
// kingsandthings/
// @author Brandon Schurman
//

public class MasterThief extends SpecialCharacter
{
    /**
     * CTOR 
     */
    public MasterThief(){
        super("path/to/front.png", "path/to/back.png", "Master Thief", 
               4, false, false, false, false);
    }

    public void stealGold( /* param later */ ){
        // TODO have to figure out how we will implement this feature
    }

    public void stealRandomCounter( /* param */ ){
        // TODO
    }
}
