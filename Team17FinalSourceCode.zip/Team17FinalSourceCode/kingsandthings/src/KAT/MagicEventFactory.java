package KAT;

public class MagicEventFactory
{
    public static MagicEvent createMagicEvent( String name ){
        MagicEvent magicEvent = null;

        // TODO create correct magicEvent subclass corresponding to name

        return magicEvent;
    }
}
