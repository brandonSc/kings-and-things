package KAT;

public class SpecialIncomeFactory
{
    public static SpecialIncome createSpecialIncome( String name ){
        SpecialIncome specialIncome = null;

        // TODO create specialIncome subclass corresponding to name

        return specialIncome;
    }
}
